import os
import sys
#custom_path='../Lib/site-packages'
c_path='./py_thon/Lib/site-packages'
#sys.path.append(custom_path)
sys.path.append(c_path)
from flask import Flask
import subprocess  
# Define the URL and Chrome profile
profile_dir = "Default"  # Change this to your specific profile directory if needed

# Name of the program or file you want to open
program_name = "Google/Chrome/Application/chrome.exe"

# Construct the path to the "Program Files" directory
program_files = os.environ.get("PROGRAMFILES", "C:\\Program Files")
program_files_x86 = os.environ.get("PROGRAMFILES(X86)", "C:\\Program Files (x86)")

# Construct the full path to the program
program_path = os.path.join(program_files, program_name)

# Check if the program exists in "Program Files"
if not os.path.exists(program_path):
    # Check "Program Files (x86)" if not found in "Program Files"
    program_path = os.path.join(program_files_x86, program_name)

# Ensure the path exists before attempting to open

app = Flask(__name__)

@app.route('/automa')
def au():
   url = "chrome-extension://infppggnoaenmfagbfknfkancpbljcca/execute.html#/I-pYhZNkf6c6Ylh9mCSYZ"
   if os.path.exists(program_path):
    # Command to open Chrome with the specific URL and profile
    subprocess.Popen([program_path, f'--profile-directory={profile_dir}', url])
   else:
       print(f"Program not found: {program_name}")
   return "ok"
@app.route("/astop")
def aus():
   url = "chrome-extension://infppggnoaenmfagbfknfkancpbljcca/execute.html#/ytbEgo7rf7Ppa6GRXJkAx"
   if os.path.exists(program_path):
    # Command to open Chrome with the specific URL and profile
    subprocess.Popen([program_path, f'--profile-directory={profile_dir}', url])
   else:
       print(f"Program not found: {program_name}")
   return "ok"
   
if __name__ == '__main__':
    app.run(debug=True,host='0.0.0.0',port=5000)